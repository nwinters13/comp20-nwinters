
//checks all of the required materials
var express = require('express');
var http = require('http');
var path = require('path');
var mongo = require('mongodb');
var app = express();


/* says which db to use */
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'http://young-mountain-1326.herokuapp.com/gamecenter';

//requires mongo and gets the database
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

/*
 * my getDate function is straight from lab 7 where I get the date
 *   to be displayed as a string timestamp
 */
function getDate() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var hour = (date.getHours() + 20) % 24;
    var minute = date.getMinutes();
    return month + "/" + day + "/" + year + " " + hour + ":" + minute;
}


// all environments to use
app.use(express.json());
app.use(express.urlencoded());

/*
 * Setting things for the app
 */
app.set('port', process.env.PORT || 3000);
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.methodOverride());

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}


/*
 * The / get decides what is displayed on the basic heroku webpage.
 *   It will sort the collection based on score and store it all into
 *   an html table, then send that table to be displayed
 */
app.get('/', function(req, res) {
  db.collection('scores', function(er, collection) {
    collection.find().sort({score: -1}).toArray(function(err, results) {
      if(err) {
        throw err;
      }
      else {
        res.setHeader('content-type', 'text/html'); //set the content
        var info = '<!DOCTYPE HTML><html><body><h1>Game Center</h1><table><tr><td>Username</td><td>Score</td><td>Date</td><tr>';
        for(var i = 0; i < results.length; i++){
          info += '<tr><td>' + results[i]['username'] + '</td><td>' + results[i]['score'] + '</td><td>' + results[i]['created_at'] + '</td></tr>';
        }
        info += '</table></body></html>'; //close off the content
        res.send(info); //send the content
      }
    })
  })
});


/*
 * The get for the /scores.json file will take the query and sort it
 *   based off of the name it finds. If there is an error, it throws
 *   an error. If no name is provided no scores are provided. If
 *   a name is provided then it only provides scores with that name
 */
app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
        var name = req.query.username; //querys for a username
        if(req.query.username){
          col.find({username: name}).sort({score: -1}).toArray(function(err, x){ //attempts to sort
            if(err){
              req.send(500, 'Name does not exist'); //a failure
            }
            else{
              res.send(x); //a successful send
            }
          });
        }
        else res.send([]);
    });
  });
});


/*
 * The /submit.json function allows cross origin resource sharing then gets the
 *   request and attempts to insert that request into the given collection
 *   If any values are null, then that data is not inserted
 */
app.post('/submit.json', function (req, res){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
      mongo.Db.connect(mongoUri, function (err, db){
        db.collection("scores", function (er, collection){
          var score = Number(req.body.score);
          var name = req.body.username;
          var grid = req.body.grid;
          var created_at = getDate();
          if(name != null && grid != null && score != null)
            collection.insert({"username": name, "score": score, "grid": grid, "created_at": created_at}, function (err, r){res.send(200)});
        });
      });
});
      

/*
 * Jasper's code for running the server
 */
http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});